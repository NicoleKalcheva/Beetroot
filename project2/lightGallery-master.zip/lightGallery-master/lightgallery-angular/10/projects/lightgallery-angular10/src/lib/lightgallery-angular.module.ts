import { NgModule } from '@angular/core';
import { LightgalleryComponent } from './lightgallery-angular.component';

@NgModule({
    declarations: [LightgalleryComponent],
    imports: [],
    exports: [LightgalleryComponent],
})
export class LightgalleryModule {}
